package com.test.apps;

import java.util.List;

public class Student {
	private Integer stId;
	private List<Books> books;

	public Integer getStId() {
		return stId;
	}

	public void setStId(Integer stId) {
		this.stId = stId;
	}

	public List<Books> getBooks() {
		return books;
	}

	public void setBooks(List<Books> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Student [stId=" + stId + ", books=" + books + "]";
	}

}