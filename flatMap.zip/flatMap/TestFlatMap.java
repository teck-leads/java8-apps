package com.test.apps;
import java.util.List;
import java.util.ArrayList;

public class TestFlatMap {
	
	public static void main(String[] args) {
		Student st1=new Student();
		Books b1=new Books();
		Books b2=new Books();
		b1.setBookId(101);
		b1.setBookName("spring");
		
		b2.setBookId(102);
		b2.setBookName("springBoot");
		
		List<Books> b1ls=new ArrayList<>();
		st1.setStId(1001);
		b1ls.add(b1);
		b1ls.add(b2);
		st1.setBooks(b1ls);
		
		
		Student st2=new Student();
		Books b3=new Books();
		Books b4=new Books();
		b3.setBookId(103);
		b3.setBookName("Kubernates");
		
		b4.setBookId(104);
		b4.setBookName("AWS");
		
		List<Books> b2ls=new ArrayList<>();
		st2.setStId(1002);
		b2ls.add(b3);
		b2ls.add(b4);
		st2.setBooks(b2ls);
		
		
		List<Student> students=new ArrayList<>();
		students.add(st1);
		students.add(st2);
		
		
		students.forEach(st->{
			
			System.out.println(st.getStId()+" "+st.getBooks() );
		});
		
	}
	
	

}
